#include <QCoreApplication>
#include <iostream>
#include<iomanip>

using namespace std;

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    int n;
    cout<<"Entrer le nombre de ligne et le nombre de colonne"<<endl;
    cin>>n;
    int mata[n][n];
    cout<<" Entrer la valeur de la matrice A"<<endl;
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cout<<" Entrer la valeur : ";
            cin>>mata[i][j];
       }
    }


    for(int i=0;i<n;i++){
        cout<<" "<<endl;
        for(int j=0;j<n;j++){
            cout<<setw(5)<<mata[i][j]<<" ";

        }
    }
    cout<<endl;

    cout<<" Entrer la valeur de la matrice B"<<endl;
    int matb[n][n];
    for(int i=0;i<n;i++){
        for(int j=0;j<n;j++){
            cout<<" Entrer la valeur : ";
            cin>>matb[i][j];


        }
    }

    for(int i=0;i<n;i++){
        cout<<" "<<endl;
        for(int j=0;j<n;j++){
            cout<<setw(5)<<matb[i][j]<<" ";

        }
    }
    cout<<endl;

    int matc[n][n];
    int som=0;
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            for(int k=0; k<n; k++){
                som=mata[i][k]*matb[k][j]+som;

            }
    matc[i][j]=som;
            som=0;
        }
    }
    cout<<endl;
    cout<<"Le produit de votre matrice est : "<<endl;
    for(int i=0;i<n;i++){
        cout<<" "<<endl;
        for(int j=0;j<n;j++){
            cout<<setw(5)<<matc[i][j]<<" ";
        }
    }
    return a.exec();
}
